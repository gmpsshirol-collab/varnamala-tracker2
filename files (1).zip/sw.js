const CACHE_NAME = 'varnamala-v1';
const urlsToCache = [
  '/varnamala-tracker/',
  '/varnamala-tracker/index.html',
  '/varnamala-tracker/manifest.json'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(urlsToCache))
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request).then(response => {
      return response || fetch(event.request);
    })
  );
});
